@f = ( "global.pl3", "asm41.pl3", "asm42.pl3", "asm43.pl3", "asm44.pl3",
	"asm45.pl3", "asm46.pl3", "asm47.pl3", "asm48.pl3", "asm49.pl3",
	"asm4A.pl3", "asm4B.pl3", "asm4C.pl3", "asm4D.pl3", "asm4E.pl3",
	"keywrd.pl3");

foreach  (@f) {
	$out = $_;
	$out =~ s/3$/m/;
	print "../asm804/$out\n";
	open(SRC, "<$_") || die;
	print <SRC>;
}
