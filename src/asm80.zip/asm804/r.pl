


sub chg {
	my($prefix, $addr, $suffix) = @_;
	my($haddr) = hex($addr);
	my($delta) = 0;

	if (0x91AB <= $haddr && $haddr <= 0x6818) {
		$delta = 0x2C8C;
	} elsif (0x94F1 <= $haddr && $haddr <= 0x9538) {
		$delta = 0x2CA0;
	} elsif (0x9539 <= $haddr && $haddr <= 0x9557) {
		$delta = 0x2C9F;
	} elsif (0x9958 <= $haddr && $haddr <= 0x9A75) {
		$delta = 0x2F57;
	} elsif (0x9A78 <= $haddr && $haddr <= 0x9B33) {
		$delta = 0x2F56;
	} elsif (0x9B35 <= $haddr && $haddr <= 0x9B39) {
		$delta = 0x2F57;
	} elsif (0x7960 <= $haddr && $haddr <= 0x7E50) {
		$delta = 0xBF2;
	} elsif (0x8185 <= $haddr && $haddr <= 0x8371) {
		$delta = 0x1406;
	} elsif (0x85E7 <= $haddr && $haddr <= 0x8643) {
		$delta = 0x1425;
	} elsif (0x8D2B <= $haddr && $haddr <= 0x8EE1) {
		$delta = 0x2A72;
	} elsif (0x8EF2 <= $haddr && $haddr <= 0x8F0A) {
		$delta = 0x2A7C;
	} elsif (0x9B3B <= $haddr && $haddr <= 0x9B3D) {
		$delta = 0x2F48;
	} elsif (0x9B40 <= $haddr && $haddr <= 0x9B57) {
		$delta = 0x2F45;
	} elsif (0x9B64 <= $haddr && $haddr <= 0x9B68) {
		$delta = 0x2F51;
	} elsif (0x9B6C <= $haddr && $haddr <= 0x9B72) {
		$delta = 0x2F52;
	} elsif (0x9B7C <= $haddr && $haddr <= 0x9C2B) {
		$delta = 0x2F5B;
	} elsif (0x9C2C <= $haddr && $haddr <= 0x9C30) {
		$delta = 0x2F52;
	} elsif (0x9C3D <= $haddr && $haddr <= 0x9C5A) {
		$delta = 0x2F56;
	} elsif (0x9C60 <= $haddr && $haddr <= 0x9C6E) {
		$delta = 0x27FD;
	} elsif (0x9C84 <= $haddr && $haddr <= 0x9CB7) {
		$delta = 0x2716;
	} elsif (0x9CB8 <= $haddr && $haddr <= 0x9D22) {
		$delta = 0x27BA;
	} elsif (0x9D23 <= $haddr && $haddr <= 0x9D2A) {
		$delta = 0x2C04;
	} elsif (0x9D2F <= $haddr && $haddr <= 0x9D69) {
		$delta = 0x3025;
	} 
	if ($delta == 0) {
		return "$prefix\$$addr$suffix";
	}
	$addr = sprintf "%04X", $haddr - $delta;

	if ($prefix eq "asc" || $prefix eq "off") {
		$prefix .= "\$";
	} else {
		$prefix = substr($prefix, 0, 1);
	}
	return "$prefix$addr$suffix";
}


sub cvt {

	rename($file, "$file.orig");

	open (SRC, "<$file.orig") || die;
	open (DST, ">$file") || die;

	while (<SRC>) {
		s/\b([bw][0-5]?|asc|off)\$([0-9A-F]+)([p0\$]*)/chg($1, $2, $3)/ge;
		print DST;
	}
}

$file = "asm41.pl3";
cvt;
$file = "asm42.pl3";
cvt;
$file = "asm43.pl3";
cvt;
$file = "asm44.pl3";
cvt;
$file = "asm45.pl3";
cvt;
$file = "asm46.pl3";
cvt;
$file = "asm47.pl3";
cvt;
$file = "asm48.pl3";
cvt;
$file = "asm49.pl3";
cvt;
$file = "asm4A.pl3";
cvt;
$file = "asm4B.pl3";
cvt;
$file = "asm4C.pl3";
cvt;
$file = "asm4D.pl3";
cvt;

