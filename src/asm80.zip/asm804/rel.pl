$#ARG3 != 3 || die "usage: rel.pl file offset\n";

$file = shift @ARGV;
$offset = hex(shift @ARGV);


open SRC, "<$file" || die "can't open $file\n";

while (<SRC>) {
	s/^( {11})([0-9A-F]{4})/sprintf "%s%04X", $1, hex($2) + $offset/e;
	print;
}
